package com.sebs.bodybuildinglegends.data.network

class LegendAPI(
    var id: Long
)


