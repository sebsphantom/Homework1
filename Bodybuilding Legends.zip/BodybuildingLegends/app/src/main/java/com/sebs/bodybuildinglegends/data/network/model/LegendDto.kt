package com.sebs.bodybuildinglegends.data.network.model

data class LegendDto(
    var id: Long


)
