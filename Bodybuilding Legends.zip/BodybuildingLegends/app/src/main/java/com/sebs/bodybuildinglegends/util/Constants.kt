package com.sebs.bodybuildinglegends.util

object Constants {

    const val DATABASE_NAME = "legends_db"
    const val DATABASE_LEGEND_TABLE = "legend_data_table"

}


